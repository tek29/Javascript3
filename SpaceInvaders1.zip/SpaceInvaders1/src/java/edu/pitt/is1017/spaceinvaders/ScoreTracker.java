package edu.pitt.is1017.spaceinvaders;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.*;

public class ScoreTracker {

	private User user; 
	private int currentScore, highestScore;
	private String gameID;

	public ScoreTracker (User user){   //constructor
		this.user = user;
		currentScore = 0; //sets score to 0
		UUID uid =  UUID.randomUUID();
		gameID= uid.toString();//instantiate string to random UUID
		DbUtilities dbUtil = new DbUtilities();
		String highScore = "SELECT MAX(scoreValue) AS highScore FROM finalscores WHERE fk_userID ='"+ user.getUserID() +"';"; //returns your best score ever
		ResultSet rs = dbUtil.getResultSet(highScore);
		try {
			if(rs.next()){
				this.highestScore = rs.getInt("highScore");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// dbUtil.executeQuery(highScore);
		//call user method to get userID value
	}
	public String timeDate(){
	String timeDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Calendar cal = Calendar.getInstance();
	timeDate=dateFormat.format(cal.getTime());//timeDate=dateFormat.format(cal.getTime()).toString();
	return timeDate;
	}

	public void recordScore (int point){	// every time a hit or a miss occurs,Store each hit or miss in database
		currentScore = currentScore + point;
		int scoreType = 1;
		if(point < 1){
			scoreType = 0; 
		}
		DbUtilities dbUtil = new DbUtilities();
		String sql = "INSERT INTO runningscores (gameID, scoreType, scoreValue, fk_userID, dateTimeEntered) "
				+ "VALUES ('" + gameID + "', " + scoreType + ", " + currentScore + ", "
				+ user.getUserID() + ", '" + timeDate() + "');";
		dbUtil.executeQuery(sql);
	}

	public void recordFinalScore (){
		// before closing game, insert currentscore into database table, finalscore
		DbUtilities dbUtil = new DbUtilities();
		String finalScore = "INSERT INTO finalscores (gameID, fk_userID, dateTimeEntered) "
				+ "VALUES ('" + gameID + "', " + user.getUserID() + ", '" + timeDate() + "');";
		dbUtil.executeQuery(finalScore);
	}

	//getters and setters
	public int getCurrentScore() {
		return currentScore;
	}

	public void setCurrentScore(int currentScore) {
		this.currentScore = currentScore;
	}

	public int getHighestScore() {
		// 
		return highestScore;
	}

	public void setHighestScore(int highestScore) {
		this.highestScore = highestScore;

	}
}
